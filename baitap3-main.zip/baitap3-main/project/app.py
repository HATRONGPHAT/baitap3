from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
import psycopg2
from functools import wraps
from flask import abort
from psycopg2.extras import DictCursor
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from flask import render_template

app = Flask(__name__)
app.secret_key = '1'

def send_reminders():
    conn = get_db_connection()
    now = datetime.now()
    tasks = conn.execute('SELECT * FROM tasks WHERE reminder <= ? AND reminder IS NOT NULL', (now,)).fetchall()
    for task in tasks:
        # Gửi email hoặc thông báo qua hệ thống
        send_email(task['email'], f"Nhắc nhở công việc: {task['name']}", f"Chi tiết: {task['details']}")
        # Xóa hoặc cập nhật reminder sau khi đã nhắc
        conn.execute('UPDATE tasks SET reminder = NULL WHERE id = ?', (task['id'],))
    conn.commit()
    conn.close()

def send_email(to_email, subject, body):
    # Gửi email qua SMTP
    with smtplib.SMTP('smtp.example.com', 587) as server:
        server.starttls()
        server.login('your_email@example.com', 'your_password')
        message = f"Subject: {subject}\n\n{body}"
        server.sendmail('your_email@example.com', to_email, message)

# Bắt đầu scheduler
scheduler = BackgroundScheduler()
scheduler.add_job(func=send_reminders, trigger="interval", minutes=1)
scheduler.start()

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        print("Session in admin_required:", session)  # Debugging
        if session.get('role') != 'admin':  # Chỉ Admin mới được phép
            abort(403)  # Forbidden
        return f(*args, **kwargs)
    return decorated_function
# Kết nối PostgreSQL
def get_db_connection():
    conn = psycopg2.connect(
        dbname='thongtin',
        user='postgres',
        password='2111',
        host='localhost',
        port='5432'
    )
    return conn

# Kiểm tra đăng nhập
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Vui lòng đăng nhập trước.", "warning")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function
# Route Admin để xem danh sách người dùng
@app.route('/admin/users')
@admin_required
def admin_users():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)  # Sử dụng DictCursor
    cur.execute('SELECT id, username, role FROM users ORDER BY id ASC;')  # Chỉ lấy các cột cần thiết
    users = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('admin_users.html', users=users)

@app.route('/admin/users/<int:user_id>')
@admin_required
def admin_user_detail(user_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT id, username, role FROM users WHERE id = %s;', (user_id,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    
    if user:
        return render_template('admin_user_detail.html', user=user)
    else:
        flash('Không tìm thấy người dùng.', 'danger')
        return redirect(url_for('admin_users'))
# Trang chủ
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('task_management'))
    return redirect(url_for('login'))

# Trang đăng ký
@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('task_management'))
    
    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        role = 'user'  # Gán vai trò mặc định là 'user'

        if not username or not password or not confirm_password:
            flash('Vui lòng điền đầy đủ thông tin.', 'warning')
            return redirect(url_for('register'))
        
        if password != confirm_password:
            flash('Mật khẩu và nhập lại mật khẩu không khớp.', 'danger')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')

        conn = get_db_connection()
        cur = conn.cursor()
        try:
            cur.execute('INSERT INTO users (username, password, role) VALUES (%s, %s, %s)', (username, hashed_password, role))
            conn.commit()
            flash('Đăng ký thành công! Bạn có thể đăng nhập ngay bây giờ.', 'success')
            return redirect(url_for('login'))
        except IntegrityError:
            conn.rollback()
            flash('Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.', 'danger')
        except Exception as e:
            conn.rollback()
            flash(f'Đã xảy ra lỗi: {e}', 'danger')
        finally:
            cur.close()
            conn.close()
    
    return render_template('register.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        # Chuyển hướng admin đến quản lý công việc
        if session.get('role') == 'admin':
            return redirect(url_for('manage_tasks'))
        return redirect(url_for('task_management'))

    if request.method == 'POST':
        username = request.form.get('username').strip()
        password = request.form.get('password')

        if not username or not password:
            flash('Vui lòng điền đầy đủ tên người dùng và mật khẩu.', 'warning')
            return redirect(url_for('login'))

        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=DictCursor)
        cur.execute('SELECT id, username, password, role FROM users WHERE username = %s', (username,))
        user = cur.fetchone()
        cur.close()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']

            flash('Đăng nhập thành công!', 'success')

            # Chuyển hướng dựa trên vai trò
            if user['role'] == 'admin':
                return redirect(url_for('admin_tasks'))  # Quản lý công việc admin
            return redirect(url_for('task_management'))  # Trang công việc của user thường
        else:
            flash('Tên đăng nhập hoặc mật khẩu không đúng.', 'danger')

    return render_template('login.html')
# Đăng xuất
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    flash('Bạn đã đăng xuất.', 'success')
    return redirect(url_for('login'))
# Trang quản lý công việc
@app.route('/tasks')
@login_required
def task_management():
    user_id = session.get('user_id')
    role = session.get('role')

    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)

    # Nếu là admin, hiển thị tất cả công việc
    if role == 'admin':
        cur.execute('SELECT * FROM tasks')
    else:
        # Nếu là user, chỉ hiển thị công việc của người đó
        cur.execute('SELECT * FROM tasks WHERE user_id = %s', (user_id,))

    tasks = cur.fetchall()

    # Thống kê công việc
    cur.execute("SELECT COUNT(*) FROM tasks WHERE status = 'completed'")
    completed = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM tasks WHERE status = 'pending'")
    pending = cur.fetchone()[0]

    cur.close()
    conn.close()

    # Truyền thêm completed và pending vào template
    return render_template('task_management.html', tasks=tasks, completed=completed, pending=pending)
#xóa người dùng
@app.route('/delete_user/<int:user_id>', methods=['POST'])
@admin_required
def delete_user(user_id):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute('DELETE FROM users WHERE id = %s', (user_id,))
        conn.commit()
        flash('Người dùng đã được xóa thành công.', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Không thể xóa người dùng: {e}', 'danger')
    finally:
        cur.close()
        conn.close()
    return redirect(url_for('admin_user_management'))
    #user
@app.route('/user')
@admin_required
def user_management():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)

    # Lấy danh sách người dùng
    cur.execute('SELECT id, username FROM users')
    users = cur.fetchall()

    # Lấy danh sách công việc của từng người dùng
    cur.execute('''
        SELECT tasks.id, tasks.task, tasks.detail, tasks.day, tasks.start_time, tasks.end_time, tasks.priority, tasks.status, tasks.user_id, users.username
        FROM tasks
        LEFT JOIN users ON tasks.user_id = users.id
        ORDER BY tasks.user_id ASC, tasks.id ASC
    ''')
    tasks = cur.fetchall()

    cur.close()
    conn.close()

    return render_template('user_management.html', users=users, tasks=tasks)

# Trang thêm công việc
@app.route('/add_task', methods=['GET', 'POST'])
@login_required
def add_task():
    user_id = session.get('user_id')  # Lấy user_id từ session

    if request.method == 'POST':
        task = request.form['task']
        detail = request.form['detail']
        day = request.form['day']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        priority = request.form['priority']
        status = 'pending'

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            'INSERT INTO tasks (task, detail, day, start_time, end_time, priority, status, user_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)',
            (task, detail, day, start_time, end_time, priority, status, user_id)
        )
        conn.commit()
        cur.close()
        conn.close()
        flash('Thêm công việc thành công!', 'success')
        return redirect(url_for('task_management'))

    return render_template('add_task.html')


# Sửa công việc
@app.route('/edit_task/<int:task_id>', methods=['GET', 'POST'])
@login_required
def edit_task(task_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM tasks WHERE id = %s', (task_id,))
    task = cur.fetchone()

    if not task:
        flash('Không tìm thấy công việc này.', 'danger')
        return redirect(url_for('task_management'))

    if request.method == 'POST':
        task_name = request.form['task']
        detail = request.form['detail']
        day = request.form['day']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        priority = request.form['priority']

        cur.execute(
            'UPDATE tasks SET task = %s, detail = %s, day = %s, start_time = %s, end_time = %s, priority = %s WHERE id = %s',
            (task_name, detail, day, start_time, end_time, priority, task_id)
        )
        conn.commit()
        cur.close()
        conn.close()
        flash('Công việc đã được cập nhật!', 'success')
        return redirect(url_for('task_management'))

    cur.close()
    conn.close()
    return render_template('edit_task.html', task=task)

# Đánh dấu hoàn thành công việc
# Đánh dấu hoàn thành công việc
@app.route('/complete_task/<int:task_id>', methods=['POST'])
@login_required
def complete_task(task_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE tasks SET status = %s WHERE id = %s', ('completed', task_id))
    conn.commit()
    cur.close()
    conn.close()
    flash('Công việc đã được đánh dấu hoàn thành!', 'success')
    # Redirect về trang hiện tại (bao gồm bộ lọc nếu có)
    return redirect(url_for('filtered_tasks', filter_type='all'))
# Đánh dấu chưa hoàn thành
@app.route('/mark_incomplete/<int:task_id>', methods=['POST'])
@login_required
def mark_incomplete(task_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE tasks SET status = %s WHERE id = %s', ('pending', task_id))
    conn.commit()
    cur.close()
    conn.close()
    flash('Công việc đã chuyển về trạng thái chưa hoàn thành!', 'info')
    # Redirect về trang hiện tại (bao gồm bộ lọc nếu có)
    return redirect(url_for('filtered_tasks', filter_type='all'))
# Xóa công việc
@app.route('/delete_task/<int:task_id>', methods=['POST'])
@login_required
def delete_task(task_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM tasks WHERE id = %s', (task_id,))
    conn.commit()
    cur.close()
    conn.close()
    flash('Xóa công việc thành công!', 'success')
    return redirect(url_for('task_management'))

@app.route('/tasks/<filter_type>')
@login_required
def filtered_tasks(filter_type):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)

    if filter_type == 'completed':
        cur.execute("SELECT * FROM tasks WHERE status = 'completed'")
    elif filter_type == 'pending':
        cur.execute("SELECT * FROM tasks WHERE status = 'pending'")
    else:
        cur.execute("SELECT * FROM tasks")

    tasks = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('task_management.html', tasks=tasks, filter_type=filter_type)
#
@app.route('/search', methods=['GET'])
@login_required
def search():
    query = request.args.get('query', '').strip()
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tasks WHERE task ILIKE %s", (f"%{query}%",))
    tasks = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('task_management.html', tasks=tasks, query=query)

@app.route('/stats')
@login_required
def stats():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM tasks WHERE status = 'completed'")
    completed = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM tasks WHERE status = 'pending'")
    pending = cur.fetchone()[0]
    cur.close()
    conn.close()
    return render_template('stats.html', completed=completed, pending=pending)

@app.route('/task_management')
@login_required
def task_management_with_role():
    user_id = session.get('user_id')
    role = session.get('role')

    conn = get_db_connection()
    cur = conn.cursor()

    if role == 'admin':
        # Admin xem tất cả công việc
        cur.execute('''
            SELECT 
                tasks.id, 
                tasks.task, 
                tasks.detail, 
                tasks.day, 
                tasks.start_time, 
                tasks.end_time, 
                tasks.priority, 
                tasks.status, 
                users.username
            FROM tasks
            LEFT JOIN users ON tasks.user_id = users.id
            ORDER BY tasks.id ASC;
        ''')
    else:
        # Người dùng chỉ xem công việc của chính mình
        cur.execute('''
            SELECT 
                tasks.id, 
                tasks.task, 
                tasks.detail, 
                tasks.day, 
                tasks.start_time, 
                tasks.end_time, 
                tasks.priority, 
                tasks.status
            FROM tasks
            WHERE tasks.user_id = %s
            ORDER BY tasks.id ASC;
        ''', (user_id,))
    
    tasks = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('task_management.html', tasks=tasks)

# Route quản lý công việc dành cho admin
@app.route('/admin/tasks')
@admin_required
def admin_tasks():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)

    # Lấy danh sách công việc của tất cả người dùng
    cur.execute('''
        SELECT 
            tasks.id AS task_id,
            tasks.task,
            tasks.detail,
            tasks.day,
            tasks.start_time,
            tasks.end_time,
            tasks.priority,
            tasks.status,
            users.username
        FROM tasks
        LEFT JOIN users ON tasks.user_id = users.id
        ORDER BY tasks.id ASC;
    ''')
    tasks = cur.fetchall()

    cur.close()
    conn.close()

    return render_template('admin_tasks.html', tasks=tasks)
#
@app.route('/user_management')
@admin_required
def admin_user_management():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)  # Sử dụng DictCursor để làm việc với dữ liệu theo dạng từ điển

    # Lấy danh sách tất cả người dùng từ cơ sở dữ liệu
    cur.execute('SELECT id, username, role, is_admin FROM users ORDER BY id ASC;')
    users = cur.fetchall()

    cur.close()
    conn.close()

    # Truyền dữ liệu vào template để hiển thị
    return render_template('user_management.html', users=users)

@app.route('/manage_tasks')
@login_required
def manage_tasks():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=DictCursor)
    cur.execute('''
        SELECT 
            tasks.id AS task_id, 
            tasks.task, 
            tasks.detail, 
            tasks.day, 
            tasks.start_time, 
            tasks.end_time, 
            tasks.priority, 
            tasks.status, 
            users.username
        FROM tasks
        LEFT JOIN users ON tasks.user_id = users.id
        ORDER BY tasks.id ASC;
    ''')
    tasks = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('task_management.html', tasks=tasks)
#
#
@app.route('/set_reminder/<int:task_id>', methods=['GET', 'POST'])
def set_reminder(task_id):
    if request.method == 'POST':
        reminder_time = request.form.get('reminder')  # Lấy thời gian nhắc nhở từ form

        conn = get_db_connection()  # Tạo kết nối cơ sở dữ liệu
        cur = conn.cursor()  # Tạo cursor
        cur.execute('UPDATE tasks SET reminder = %s WHERE id = %s', (reminder_time, task_id))
        conn.commit()  # Lưu thay đổi
        cur.close()  # Đóng cursor
        conn.close()  # Đóng kết nối

        flash('Nhắc nhở đã được thiết lập!', 'success')
        return redirect(url_for('manage_tasks'))
    
    return render_template('set_reminder.html', task_id=task_id)

#

reminder_time = datetime.strptime('2024-11-20 15:30:00', '%Y-%m-%d %H:%M:%S')


if __name__ == '__main__':
    app.run(debug=True)