from werkzeug.security import generate_password_hash
import psycopg2

# Mã hóa mật khẩu admin
hashed_password = generate_password_hash('1', method='pbkdf2:sha256')

# Kết nối vào cơ sở dữ liệu và thêm tài khoản admin
conn = psycopg2.connect(
    dbname='thongtin',
    user='postgres',
    password='2111',
    host='localhost',
    port='5432'
)
cur = conn.cursor()
cur.execute('INSERT INTO users (username, password, role) VALUES (%s, %s, %s)', ('admin97', 123456, 'admin97'))
conn.commit()
cur.close()
conn.close()
